var $ = require('jquery');

var RPC = {
	version: 1.1,
	vue: null,
	user: null,
	pass: null,
	os: null,
	homedir: null,
	datadir: null,
	backupdir: null,
	url: 'http://127.0.0.1:55555',
	walletIsLocked: false,
	passphrase: null,
	updateURL: 'https://github.com/pura-dev/pura-release/releases',

	checkForUpdates: function() {
		var vueData = RPC.vue.$data,
		    parent = RPC.vue.$parent;

		$.getJSON('http://87.121.98.227', function(data) {
		    var currentVersion = parseFloat(RPC.version),
		        latestVersion = parseFloat(data.version);
		    if (!isNaN(currentVersion) && !isNaN(latestVersion) && (currentVersion < latestVersion)) {
		        parent.updateAvailable = true;
		        parent.updateURL = RPC.updateURL;
		    }
		});
	},
	setAuth: function() {
		var fs = require('fs'),
			os = require('os');

		RPC.os = os.platform();
		RPC.homedir = os.homedir();
		RPC.datadir = RPC.os == 'darwin' ? '/Library/Application Support/Pura/' : '\\AppData\\Roaming\\Pura\\';
		RPC.backupdir = RPC.homedir + RPC.datadir + 'backups' + (RPC.os == 'darwin' ? '/' : '\\');

		return $.Deferred(function() { // <-- see returning Deferred object
            var self = this;

            fs.readFile(RPC.homedir + RPC.datadir + 'pura.conf', 'utf8', function (err, data) {
				if (err) {
					console.log(err);
					self.reject();
				} else {
					var lines = data.toString().split("\n"),
					user = lines[0].split("=")[1],
					pass = lines[1].split("=")[1];

					RPC.user = user;
					RPC.pass = pass;
					self.resolve();
				}
			});
        });
	},
	checkWalletLock: function () {
		var data = '{ "method": "walletlock", "params": [""] }',
			parent = RPC.vue.$parent,
			vueData = RPC.vue.$data,
			lockDefer = $.Deferred();

		parent.status = 'Checking wallet...';

		$.when(RPC.call(data, false))
			.then(function(){
				lockDefer.resolve();
			}, function(data) {
				if (data.responseJSON.error.code === -15) {
					lockDefer.resolve();
				} else {
					console.log('Wallet locked');
					parent.status = 'Please enter your passphrase below.';
					RPC.walletIsLocked = true;
					parent.walletLocked = true;
					lockDefer.reject();
				}
			});

		return lockDefer.promise();
	},
	checkBlockchainSync: function(vue) {
		var deferred = $.Deferred(),
			parent = vue.$parent;

		$.getJSON('https://chainz.cryptoid.info/pura/api.dws?q=getblockcount', function(data){
			var totalBlocks = data,
				blocks = 0,
				percentage;

			function countBlocks() {
				var data = '{ "method": "getblockcount" }';

				$.when(RPC.call(data)).then(function(data, textStatus, jqXHR){
					if (jqXHR.status === 200) {
						blocks = data.result;
						percentage = Math.ceil((blocks/totalBlocks) * 100);
						parent.status = 'Blockchain sync [ ' + blocks + ' / ' + totalBlocks + ' ] (' + percentage + '%)...';
						if (blocks < totalBlocks)
							setTimeout(countBlocks, 500);
						else deferred.resolve();
					} else {
						console.warn('getAddress returned status code ' + jqXHR.status);
					}
				});
			}

			countBlocks();
		});

		return deferred.promise();
	},
	getAddress: function (vue) {
		var data = '{ "method": "getaccountaddress", "params": [""] }',
			parent = vue.$parent,
			vueData = vue.$data;

		$.when(RPC.call(data)).then(function(data, textStatus, jqXHR){
			if (jqXHR.status === 200) {
				var address = data.result;
				vueData.address = address;
				var qrcode = new QRCode(document.getElementById("qrcode"), {
					text: "pura:" + address + "?IS=1",
					width: 138,
					height: 138,
					colorDark : "#000000",
					colorLight : "#ffffff",
					correctLevel : QRCode.CorrectLevel.H
				});
			} else {
				console.warn('getAddress returned status code ' + jqXHR.status);
			}
		});
	},
	getBalance: function (vue) {
		var data = '{ "method": "getbalance" }',
			parent = vue.$parent,
			vueData = vue.$data;

		$.when(RPC.call(data)).then(function(data, status, jqXHR){
			if (jqXHR.status === 200) {
				var balance = data.result.toString().split('.');
				vueData.balance.full = data.result;
				vueData.balance.whole = balance[0];
				vueData.balance.dec = balance[1] || "00";
			} else {
				console.warn('getBalance returned status code ' + jqXHR.status);
			}
		});
	},
	getPendingBalance: function (vue) {
		var data = '{ "method": "getunconfirmedbalance" }',
			parent = vue.$parent,
			vueData = vue.$data;

		$.when(RPC.call(data)).then(function(data, status, jqXHR){
			if (jqXHR.status === 200) {
				if (parseFloat(data.result) > 0) {
					vueData.balance.pending = data.result;
					vueData.hasPending = true;
				} else {
					vueData.hasPending = false;
				}
			} else {
				console.warn('getPendingBalance returned status code ' + jqXHR.status);
			}
		});
	},
	getMarketPrice: function(vue) {
		var vueData = vue.$data,
			parent = vue.$parent,
			currentPrice,
			btcPrice,
			change;

		$.getJSON('https://www.coinexchange.io/api/v1/getmarketsummary?market_id=57', function(data) {
			btcPrice = parseFloat(data.result.LastPrice);
			var change = data.result.Change;
			vueData.price.btc = btcPrice;
			vueData.price.change = change > 0 ? '+' + change : change;
			$.getJSON('https://api.coindesk.com/v1/bpi/currentprice.json', function(d) {
				var btcUsd = d.bpi.USD.rate_float;
				vueData.price.usd = btcUsd * btcPrice;
			});
		});
	},
	getTransactions: function(vue) {
		var data = '{ "method": "listtransactions" }',
			parent = vue.$parent,
			vueData = vue.$data;

		$.when(RPC.call(data)).then(function(data, status, jqXHR){
			if (jqXHR.status === 200) {
				var transactions = [],
				monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
				_res = data.result.reverse();

				$.each(_res, function(i, transaction) {
					var _date = new Date(transaction.time*1000),
					_kind;

					switch (transaction.category) {
						case "receive":
						_kind = "Received"; break;
						case "send":
						_kind = "Sent"; break;
					};

					var _t = {
						month: monthNames[_date.getMonth()].toUpperCase(),
						day: _date.getDate(),
						kind: _kind,
						label: transaction.label || "Pura address",
						address: transaction.address,
						amount: transaction.amount
					};
					if (transaction.confirmations < 1) _t.label += " (Pending)";
					transactions.push(_t);
				});
				vueData.transactions = transactions;
			} else {
				console.warn('getTransactions returned status code ' + jqXHR.status);
			}
		});
	},
	getHistory: function(vue) {
		var request = require('request'),
			cheerio = require('cheerio'),
			parent = vue.$parent,
			vueData = vue.$data;

		function fetchMarketDataCallback(list, data) {
			list.reverse();
			var labels = [],
			data = [];

			$.each(list, function(index, item) {
				labels.push(vue.$moment(item.date).format('MM/DD'));
				data.push(item.close);
			});

			vueData.datacollection = {
				labels: labels,
				datasets: [
				{
					borderColor: '#0fc2e0',
					backgroundColor: 'transparent',
					data: data,
					expanded: list
				}
				]
			}

			vueData.chartDataExpanded = list;
		}

		function fetchMarketData(fromDate, toDate) {
			var base = "https://coinmarketcap.com"
			var page = base+"/currencies/pura/historical-data/?start="+fromDate+"&end="+toDate

			request(page, function (error, response, html) {
				if (!error && response.statusCode == 200) {
					var list = []

					var $ = cheerio.load(html);
					var rows = $("#historical-data tbody tr")

					rows.each(function(i, el) {
						var row = $(this).children()

						list.push({
							date: $(row[0]).text(),
							open: $(row[1]).text(),
							high: $(row[2]).text(),
							low: $(row[3]).text(),
							close: $(row[4]).text(),
							volume: $(row[5]).text(),
							marketCap: $(row[6]).text()
						});

						if (i == rows.length-1) { return fetchMarketDataCallback(list, response) }
					})
				}
			});
		}

		var end = vue.$moment(new Date()).format('YYYYMMDD'),
		start = vue.$moment(new Date()).add(-1, 'month').format('YYYYMMDD');

		fetchMarketData(start, end);
	},
	sendPura: function (vue) {
		var vueData = vue.$data,
			parent = vue.$parent,
			total = vueData.amount;

		if (vueData.subtractFee) total = (vueData.amount - parseFloat(vueData.fee)).toFixed(4);

		var data = '{ "method": "sendtoaddress", "params": ["' + vueData.address + '", ' + parseFloat(total) + '] }';

		return RPC.call(data);
	},
	changePassphrase: function (vue) {
		var deferred = $.Deferred(),
			vueData = vue.$data,
			parent = vue.$parent
			data = '{ "method": "walletpassphrasechange", "params": ["' + RPC.passphrase + '", "' + vueData.newPass + '" ] }';

		RPC.call(data).done(function(data, textStatus, jqXHR){
			if (textStatus === "success") RPC.passphrase = vueData.newPass;
			deferred.resolve();
		});

		return deferred.promise();
	},
	backupWallet: function (vue, path) {
		var deferred = $.Deferred(),
			vueData = vue.$data,
			parent = vue.$parent,
			data = '{ "method": "backupwallet", "params": ["' + path + '"] }';

		RPC.call(data).done(function(data, textStatus, jqXHR){
			deferred.resolve();
		});

		return deferred.promise();
	},
	getPrivateKey: function (vue, address) {
		var deferred = $.Deferred(),
			data = '{ "method": "dumpprivkey", "params": ["' + address + '"] }';

		RPC.call(data).done(function(data, textStatus, jqXHR){
			vue.$data.privKey = data.result;
			deferred.resolve();
		});

		return deferred.promise();
	},
	shutdown: function () {
		var data = '{ "method": "stop" }';
		RPC.call(data, false);
	},
	call: function(data, performLockCheck) {
		performLockCheck = performLockCheck !== false;

		function makeCall () {
			return $.ajax({
				type: "POST",
				xhrFields: { withCredentials: true },
				headers: { 'Authorization': 'Basic ' + btoa(RPC.user + ':' + RPC.pass) },
				url: RPC.url,
				data: data
			});
		}

		if (RPC.walletIsLocked && performLockCheck) {
			return $.when(RPC.unlock).then(makeCall).then(RPC.lock);
		} else return makeCall();
		
	},
	unlock: function() {
		var data = '{ "method": "walletpassphrase", "params": ["' + RPC.passphrase + '", 120] }';
		return RPC.call(data, false);
	},
	lock: function() {
		var data = '{ "method": "walletlock", "params": [""] }';
		return RPC.call(data, false);
	}
}
