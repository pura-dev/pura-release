<template>
  <div id="app">
	  <div class="flexi-c wrapper">
      <div class="splash" v-if="showSplashScreen">
        <div class="logo"></div>
        <div class="loading-msg">
          Loading... Please wait
          <span class="loading-status">{{status}}</span>
        </div>
        <div class="passphrase" v-if="walletLocked" >
          <p>Enter wallet passphrase:</p>
          <div class="passphrase-input">
            <input type="password" v-model="passphrase" @keyup.enter="proceed()" />
            <button class="passphrase-btn" @click="proceed()">&#8594;</button>
          </div>
        </div>
      </div>

      <div class="splash" v-if="updateAvailable">
        <div class="logo"></div>
        <div class="msg">
            <p>Update required:</p>
            <a :href="updateURL" target="_blank">Click here to download</a>
        </div>
      </div>

      <navbar @openMenu="menu=true"></navbar>
      <router-view></router-view>

      <m v-if="menu" @close="menu=false"></m>
    </div>
  </div>
</template>

<style scoped lang="scss">
  @import "./assets/css/offline-theme-chrome.css";
  @import "./assets/css/offline-language-english.css";
  @import "./assets/css/offline-language-english-indicator.css";
  @import "./assets/css/global.css";
  @import "./assets/css/modal.css";
  @import "./assets/css/form.css";
  @import "./assets/css/tooltips.css";

  .wrapper {
    height: 100vh;
  }
  .splash {
    position: absolute;
    top: 0;
    bottom: 0;
    right: 0;
    left: 0;
    z-index: 9999;
    background-image: url(./assets/images/mesh-large.jpg);
    background-position: center center;
    background-repeat:  no-repeat;
    background-attachment: fixed;
    background-size:  cover;
  }
  .splash .logo {
    display: block;
    width: 200px;
    height: 47px;
    background-image: url(./assets/images/logo-white.png);
    background-position: center center;
    background-repeat: no-repeat;
    position: absolute;
    top: 50%;
    left: 50%;
    margin-left: -100px;
    margin-top: -24px;
  }
  .splash .loading-msg, .splash .msg {
    text-align: center;
    color: #fff;
    position: absolute;
    bottom: 25%;
    width: 100%;
    font: 400 14px/24px 'Montserrat', sans-serif;
    text-transform: uppercase;
  }
  .splash .msg a {
      display: inline-block;
      border: 1px solid #fff;
      color: #fff;
      text-decoration: none;
      padding: 4px 6px;
      width: auto;
      text-transform: none;
  }
  .splash .loading-status {
    display: block;
    text-transform: none;
    font: 400 10px/12px 'Montserrat', sans-serif;
  }
  .splash .passphrase {
    color: #fff;
    font: 400 14px/12px 'Open Sans', sans-serif;
    position: absolute;
    bottom: 10%;
    left: 50%;
    transform: translateX(-50%);
    text-align: center;
  }
  .splash .passphrase input[type="password"] {
    background-color: rgba(0, 0, 0, 0.3);
    border: 1px solid #fff;
    color: #fff;
    padding: 2px 4px;
    text-align: left;
    margin-top: 6px;
  }
  .splash .passphrase-btn {
    background: #fff;
    color: #000;
    border: 1px solid #fff;
    padding: 2px 4px;
  }
</style>

<script>
  import navbar from './components/Nav.vue'
  import m from './components/Menu.vue'

  export default {
    components: {
      navbar,
      m
    },
    data () {
      return {
        showSplashScreen: true,
        menu: false,
        status: 'Initializing...',
        passphrase: '',
        walletLocked: false,
        updateURL: '',
        updateAvailable: false
      }
    },
    methods: {
      proceed: function() {
        this.$children[1].testPassphrase();
      }
    },
    mounted: function() {
      /*
      setInterval(() => {
        if (this.mining) {
          this.$s.commit("iterateMiningTimer")
        }
      }, 1000);
      */
    }
  }
</script>
