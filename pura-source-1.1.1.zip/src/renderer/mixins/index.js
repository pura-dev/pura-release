export default {
  methods: {
    link: function (to) {
      if (this.$router) {
        this.$router.push(to)
      } else {
        console.log("aw")
      }
    }
  },
  filters: {
    sec: function(n) {
      var ss = n % 60;

      if(ss.toString().length <= 1) { return "0"+ss.toString(); }
      return ss.toString();
    },
    min: function(n) {
      var mm = Math.trunc(n / 60) % 60;

      if(mm.toString().length <= 1) { return "0"+mm.toString(); }
      return mm.toString();
    },
    hrs: function(n) {
      var hh = Math.trunc(n / 60 / 60);

      if(hh.toString().length <= 1) { return "0"+hh.toString(); }
      return hh.toString();
    },
    whole: function(n) {
      return n.toString().split(".")[0]
    },
    dec: function(n) {
      return n.toString().split(".")[1]
    },
    round: function(n) {
      if(!n)
          n = 0;

      n = parseFloat(Math.round(n * Math.pow(10, 2)) / Math.pow(10, 2)).toFixed(2);
      return n;
    },
    btc: function(n) {
      if(!n)
        n = 0;

      n = parseFloat(Math.round(n * Math.pow(10, 8)) / Math.pow(10, 8)).toFixed(8);
      return n;
    }
  }
}