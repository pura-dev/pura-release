<template>
  <div class="flexi-i flexi-c layout">
    <div class="b-gray my-address" @click.native="networkInfo()">
      <p class="my-address-title t-center purple">My Address</p>
      <p class="my-address-address t-center blue" v-tooltip="copymsg" data-clipboard-target="#my-address">
        <span id="my-address">{{address}}</span>
      </p>
    </div>

    <div class="layout-left">
      <div class="flexi-c r small-only">
        <div class="flexi-i b-blue">
          <p class="button-text t-center white" @click="modal='send'"><span class="up"></span> SEND</p>
        </div>
        <div class="flexi-i b-blue button-right">
          <p class="button-text t-center white" @click="modal='receive'"><span class="down"></span> RECEIVE</p>
        </div>
      </div>

      <div class="flexi-c r info bottom-gray">
        <div class="flexi-i balance">
          <p class="balance-title purple">Balance</p>
          <p class="balance-number purple">{{balance.whole}}<span class="balance-currency pink">.{{balance.dec}}</span><span class="balance-currency purple"> PURA</span></p>
          <p class="balance-change blue">{{balance.full * price.btc | btc}} BTC | ${{balance.full * price.usd | round}} USD</p>
          <p class="balance-change gray" v-if="hasPending">{{balance.pending}} PURA Pending</p>
        </div>

        <div class="flexi-i qr" id="qrcode"></div>
      </div>

      <div>
        <p class="rate-current t-center gray">1 PURA = {{price.btc | btc}} BTC | ${{price.usd | round}} USD</p>
        <div class="chart">
          <line-chart
            :options="chartOptions"
            :width="600"
            :height="300"
            :chart-data="datacollection">
          </line-chart>
        </div>
      </div>
    </div>

    <div class="flexi-i transactions b-gray">
      <div class="flexi-c r wide-only wide-only-buttons">
        <div class="flexi-i b-blue">
          <p class="button-text t-center white" @click="modal='send'"><span class="up"></span> SEND</p>
        </div>
        <div class="flexi-i b-blue button-right">
          <p class="button-text t-center white" @click="modal='receive'"><span class="down"></span> RECEIVE</p>
        </div>
      </div>

      <p class="transactions-header t-center purple" @click="modal='transactions'">Transaction History</p>

      <div class="flexi-i transactions-inner">
        <div class="flexi-c r transaction bottom-gray" v-for="t in transactions">
          <div class="flexi-i transaction-date">
            <p class="transaction-month t-center pink">{{t.month}}</p>  
            <p class="transaction-day t-center purple">{{t.day}}</p>  
          </div>
          
          <div class="flexi-i transaction-icon" :class="{'receive': t.kind == 'Received', 'mine': t.kind == 'Mined'}"></div>

          <div class="flexi-i">
            <p class="transaction-kind purple" :class="{'transaction-kind-only': t.label == null}">{{t.kind}} PURA</p>
            <p class="transaction-label pink">{{t.label}} <a href="#" v-tooltip="t.address">...</a></p>
          </div>

          <div class="flexi-i transaction-value">
            <p class="transaction-value-amount t-right purple">{{t.amount}}</p>
            <p class="transaction-value-currency t-right purple">PURA</p>
          </div>
        </div>
      </div>
    </div>

    <send v-if="modal=='send'" @close="modal=null"></send>
    <receive v-if="modal=='receive'" @close="modal=null"></receive>
    <transactions v-if="modal=='transactions'" @close="modal=null"></transactions>
    <backupwallet v-if="modal=='backupwallet'" @close="modal=null"></backupwallet>
    <changepassphrase v-if="modal=='changepassphrase'" @close="modal=null"></changepassphrase>
    <encryptwallet v-if="modal=='encryptwallet'" @close="modal=null"></encryptwallet>
    <privatekey v-if="modal=='privatekey'" @close="modal=null"></privatekey>
    <mining v-if="modal=='mining'" @close="modal=null"></mining>
  </div>
</template>

<style>
  .chart canvas {
    margin:  0 auto;
  }
  .layout {
    /*overflow: hidden;*/
    height: calc(100vh - 40px);
  }
  .layout-left {
    flex: 1 1 auto;
  }
  .my-address {
    flex: 0 0 44px;
    padding: 10px;
  }
  .my-address-title {
    font: 400 10px/12px 'Open Sans', sans-serif;
  }
  .my-address-address {
    font: 400 10px/12px 'Montserrat', sans-serif;
  }
  .wide-only {
    display: none;
  }
  .button-right {
    margin-left: 4px;
  }
  .button-text {
    cursor: pointer;
    font: 600 14px/48px 'Montserrat', sans-serif;
  }
  .up, .down {
    display: inline-block;
    top: 2px;
    width: 14px;
    height: 14px;
    background-image: url(../assets/images/arrow.svg);
    background-size: 100% auto;
    background-position: center;
    transform: rotate(-90deg);
    cursor: pointer;
  }
  .down {
    transform: rotate(90deg);
  }
  .info {
    padding: 10px 15px;
    padding-bottom: 5px;
  }
  .balance {
    padding: 45px 0;
  }
  .balance-title {
    font: 400 11px/10px 'Open Sans', sans-serif;
  }
  .balance-number {
    font: 600 28px/32px 'Open Sans', sans-serif;
  }
  .balance-currency {
    font: 600 20px/24px 'Open Sans', sans-serif;
  }
  .balance-change {
    font: 400 10px/12px 'Open Sans', sans-serif;
  }
  .balance-up, .balance-down {
    display: inline-block;
    width: 10px;
    height: 10px;
    background-image: url(../assets/images/blue-arrow.svg);
    background-size: 100% auto;
    background-position: center;
    transform: rotate(-90deg);
  }
  .balance-down {
    transform: rotate(90deg);
  }
  .flexi-i.qr {
    flex: 0 0 138px;
    height: 138px;
  }
  .mining-stats {
    padding: 0 15px;
    padding-top: 5px;
  }
  .mining-title {
    bottom: -2px;
    left: -2px;
    padding-top: 6px;
    font: 400 11px/11px 'Open Sans', sans-serif;
  }
  .mining-stat {
    font: 400 18px/32px 'Open Sans', sans-serif;
  }
  .mining-stat-primary-number {
    font: 400 26px/32px 'Open Sans', sans-serif;
  }

  .rate-current {
    font: 400 10px/42px 'Open Sans', sans-serif;
  }
  .rate-graph {
    width: 100%;
    height: 100px;
    background-image: url(../assets/images/graph.png);
    background-size: auto 100px;
    background-position: right center;
    background-repeat: no-repeat;
  }

  .transactions {
    flex: 2 1 240px;
    width: 100%;
    overflow: hidden;
  }
  .transactions-header {
    flex: 0 0 42px;
    font: 400 12px/42px 'Open Sans', sans-serif;
    border-top: 1px solid #e7e7e7;
    border-bottom: 1px solid #e7e7e7;
  }
  .transactions-inner {
    overflow-y: auto;
    height: 342px;
  }
  .transactions-inner::-webkit-scrollbar {
   display: none;
  }
  .transaction {
    width: 100%;
    padding: 10px;
  }
  .transaction-date {
    flex: 0 0 40px;
  }
  .transaction-month {
    font: 600 16px/14px 'Open Sans', sans-serif;
  }
  .transaction-day {
    font: 600 22px/16px 'Open Sans', sans-serif;
  }
  .transaction-icon {
    flex: 0 0 70px;
    margin-right: 10px;
    background-image: url(../assets/images/icon-send.svg);
    background-size: auto 28px;
    background-position: center;
    background-repeat: no-repeat;
  }
  .transaction-icon.receive {
    background-image: url(../assets/images/icon-receive.svg);
  }
  .transaction-icon.mine {
    background-image: url(../assets/images/icon-pickaxe.svg);
  }
  .transaction-kind {
    font: 700 16px/18px 'Open Sans', sans-serif;
  }
  .transaction-label {
    font: 400 12px/14px 'Open Sans', sans-serif;
  }
  .transaction-kind-only {
    line-height: 32px;
  }
  .flexi-i.transaction-value {
    flex: 0 0 80px;
  }
  .transaction-value-amount {
    font: 400 12px/16px 'Open Sans', sans-serif;
  }
  .transaction-value-currency {
    font: 400 12px/16px 'Open Sans', sans-serif;
  }

  @media (min-width: 500px) {
    .rate-graph {
      height: 140px;
      background-size: auto 140px;
    }
  }

  @media (min-width: 700px) {
    .flexi-i.layout {
      width: 100%;
      display: flex;
      flex-direction: row;
      flex-wrap: nowrap;
      align-items: stretch;
      align-content: stretch;
    }
    .layout-left {
      flex: 1 1;
    }
    .flexi-i.transactions {
      flex: 0 0 340px;
      height: 100vh;
      padding: 20px;
      /*overflow-y: scroll;*/
    }
    .transactions-header {
      text-align: left;
      /*margin-top: 120px;*/
      margin-top: 48px;
    }
    .transaction {
      padding: 5px;
    }
    .flexi-i.transaction-date {
      flex: 0 0 30px;
    }
    .flexi-i.transaction-icon {
      flex: 0 0 50px;
      margin-right: 0;
    }
    .my-address {
      position: absolute;
      top: -42px;
      left: calc(50% - 100px);
      /*width: 200px;*/
      background: none;
    }
    .rate-graph {
      width: 100%;
      margin: 0 0;
      height: 180px;
      background-image: url(../assets/images/graph.png);
      background-size: auto 180px;
      background-position: right center;
      background-repeat: no-repeat;
    }
    .flexi-c.wide-only {
      display: flex;
    }
    .wide-only-buttons {
      flex: 0 0 48px;
    }
    .flexi-c.small-only {
      display: none;
    }
  }

  @media (min-width: 1200px) {
    .rate-graph {
      height: 240px;
      background-size: auto 240px;
    }
  }
</style>

<script>
  import send from './modals/Send.vue'
  import receive from './modals/receive.vue'
  import transactions from './modals/Transactions.vue'
  import backupwallet from './modals/BackupWallet.vue'
  import privatekey from './modals/PrivKey.vue'
  import encryptwallet from './modals/EncryptWallet.vue'
  import changepassphrase from './modals/ChangePassphrase.vue'
  import mining from './modals/Mining.vue'
  import LineChart from '../mixins/LineChart.js'

  export default {
    components: { 
      send,
      receive,
      transactions,
      backupwallet,
      privatekey,
      encryptwallet,
      changepassphrase,
      mining,
      LineChart
    },
    data () {
      return {
        address: '--',
        price: {
          usd: '--',
          btc: '--',
          change: '--'
        },
        balance: {
          full: '--',
          whole: '--',
          dec: '--',
          pending: '--'
        },
        hasPending: false,
        modal: null,
        transactions: [],
        refreshInterval: null,
        datacollection: null,
        chartDataExpanded: null,
        copymsg: 'Click to copy address',
        chartOptions: {
          responsive: false,
          maintainAspectRatio: false,
          legend: {
            display: false
          },
          tooltips: {
            enabled: true,
            custom: function(tooltip) {
              if (!tooltip) return;
              tooltip.displayColors = false;
            },
            callbacks: {
              title: function(tooltipItem, data) {
                var index = tooltipItem[0].index,
                    expanded = data['datasets'][0]['expanded'];
                return 'Close: $' + expanded[index]['close'] + ' USD';
              },
              label: function(tooltipItem, data) {
                var index = tooltipItem.index,
                    expanded = data['datasets'][0]['expanded'];
                return 'High: $' + expanded[index]['high'] + ' USD';
              },
              afterLabel: function(tooltipItem, data) {
                var index = tooltipItem.index,
                    expanded = data['datasets'][0]['expanded'];
                return 'Low: $' + expanded[index]['low'] + ' USD';
              }
            }
          }
        }
      }
    },
    methods: {
      refreshData: function() {
      var vue = this;

        $.when(RPC.getBalance(vue))
          .then(RPC.getPendingBalance(vue))
          .then(RPC.getTransactions(vue))
          .then(RPC.getMarketPrice(vue))
          .then(RPC.getHistory(vue))
          .then(function(){ if (RPC.walletIsLocked) RPC.lock(); });
      },
      testPassphrase: function() {
        var vue = this,
            vueData = this.$data,
            parent = this.$parent;

        RPC.passphrase = parent.passphrase;
        RPC.unlock()
          .then(function(data) {
            RPC.lock();
            vue.proceed();
          }, function(data) {
            console.log(data);

            if (data.responseJSON.error.code === -14) {
              parent.status = 'Invalid passphrase. Please try again.';
            } else if (data.responseJSON.error.code === -15) {
              vue.proceed();
            }
          });

      },
      proceed: function() {
        console.log('Continuing...')
        var vue = this,
            parent = this.$parent;

        RPC.checkBlockchainSync(vue)
          .then(function(){
            parent.status = 'Getting address...';
            RPC.getAddress(vue);
          })
          .then(function(){
            parent.status = 'Getting balance...';
            RPC.getBalance(vue);
          })
          .then(function(){
            parent.status = 'Checking pending balance...';
            RPC.getPendingBalance(vue);
          })
          .then(function(){
            parent.status = 'Fetching transactions...';
            RPC.getTransactions(vue);
          })
          .then(function(){
            parent.status = 'Checking market price...';
            RPC.getMarketPrice(vue);
          })
          .then(function(){
            parent.status = 'Getting historical data...';
            RPC.getHistory(vue);
          })
          .then(function(){
            if (RPC.walletIsLocked) RPC.lock();
            parent.status = 'Finished';
            parent.showSplashScreen = false;
            RPC.checkForUpdates();

            clearInterval(vue.refreshInterval);
            vue.refreshInterval = setInterval(function(){
              vue.refreshData();
            }.bind(vue), 20000);
          })
      },
      init: function() {
        var vue = this,
            parent = this.$parent;

        RPC.vue = this;

        Offline.options = {
          checkOnLoad: true,
          checks: {
            xhr: { url: 'http://www.google.com/' }
          }
        };

        $(function(){
          var $online = $('.online'),
              $offline = $('.offline');

          Offline.on('confirmed-down', function () {
            $online.fadeOut(function () {
              $offline.fadeIn();
            });
          });

          Offline.on('confirmed-up', function () {
            $offline.fadeOut(function () {
              $online.fadeIn();
            });
          });
        });

        parent.status = 'Launching RPC server...';

        const { exec } = require('child_process');
        exec('purad -server -rest -listen=1', (error, stdout, stderr) => {
            if (error) {
                console.error(`exec error: ${error}`);
                return;
            }
            console.log(`stdout: ${stdout}`);
            console.log(`stderr: ${stderr}`);
        });

        var tryReload = true;

        setTimeout(() => {
            if(tryReload === true) {
                const webContents = require('electron').remote.getCurrentWebContents();
                webContents.reload(true);
            }
          }, 10000);

        parent.status = 'Authenticating...';
        RPC.setAuth()
          .then(RPC.checkWalletLock)
          .then(function(){
            tryReload = false;
            if (!RPC.walletIsLocked) vue.proceed();
          });
      }
    },
    mounted: function () {
      new Clipboard('.my-address-address');
      this.init();
      this.$root.$on('launchModal', (modalName) => {
        this.modal = null;
        this.modal = modalName;
      });
    }
  }
</script>
