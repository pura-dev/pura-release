<template>
  <div class="navbar">
    <div class="logo" @click.native="link('/')"></div>
    <button class="menu-button" @click="$emit('openMenu')"></button>
  </div>
</template>

<style>
  .navbar {
    width: 100%;
    /*height: 40px;*/
    flex: 0 0 40px;
    border-bottom: 1px solid #e7e7e7;
    background-color: #efefef;
  }
  .logo {
    display: block;
    height: 16px;
    width: 70px;
    margin: 12px;
    background-image: url(../assets/images/logo.png);
    background-size: auto 100%;
    background-position: left center;
    background-repeat: no-repeat;
  }
  .menu-button {
    position: absolute;
    height: 22px;
    width: 22px;
    top: 9px;
    right: 9px;
    cursor: pointer;
    background-color: transparent;
    background-image: url(../assets/images/menu.png);
    background-size: auto 14px;
    background-position: center;
    background-repeat: no-repeat;
    outline: none;
    border: none;
  }
</style>
