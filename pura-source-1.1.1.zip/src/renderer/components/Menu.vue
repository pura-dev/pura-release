<template>
  <div class="modal-cover">
    <div class="modal-backdrop" @click.native="$emit('close')"></div>

    <div class="modal-body modal-menu-body">
      <div class="modal-header">
        <p class="modal-title">MENU</p>

        <button class="modal-exit small" @click="$emit('close')"></button>
      </div>

      <div class="modal-content">
        <div class="flexi-c r bottom-gray" @click="$emit('close'); openModal('send')">
          <div class="flexi-i menu-item-icon transaction-icon"></div>
          <p class="flexi-i menu-item-name purple">Send PURA</p>
        </div>

        <div class="flexi-c r bottom-gray" @click="$emit('close'); openModal('receive')">
          <div class="flexi-i menu-item-icon transaction-icon receive"></div>
          <p class="flexi-i menu-item-name purple">Receive PURA</p>
        </div>

        <div class="flexi-c r bottom-gray" @click="$emit('close'); openModal('transactions')">
          <div class="flexi-i menu-item-icon menu-item-icon-transactions"></div>
          <p class="flexi-i menu-item-name purple">Transactions</p>
        </div>

        <div class="flexi-c r bottom-gray" @click="$emit('close'); openModal('backupwallet');">
          <div class="flexi-i menu-item-icon menu-item-icon-backup"></div>
          <p class="flexi-i menu-item-name purple">Backup Wallet</p>
        </div>

        <div class="flexi-c r bottom-gray" @click="$emit('close'); openModal('privatekey');">
          <div class="flexi-i menu-item-icon menu-item-icon-key"></div>
          <p class="flexi-i menu-item-name purple">Dump Private Key</p>
        </div>

        <div class="flexi-c r bottom-gray" @click="$emit('close'); openModal('changepassphrase');" v-if="isLocked">
          <div class="flexi-i menu-item-icon menu-item-icon-settings"></div>
          <p class="flexi-i menu-item-name purple">Change Passphrase</p>
        </div>

        <div class="flexi-c r bottom-gray" @click="$emit('close'); openModal('encryptwallet');" v-if="!isLocked">
          <div class="flexi-i menu-item-icon menu-item-icon-settings"></div>
          <p class="flexi-i menu-item-name purple">Encrypt Wallet</p>
        </div>

        <!--
        <div class="flexi-c r bottom-gray" @click="$emit('close'); openModal('mining')">
          <div class="flexi-i menu-item-icon menu-item-icon-mining"></div>
          <p class="flexi-i menu-item-name purple">Mining</p>
        </div>

        <div class="flexi-c r bottom-gray">
          <div class="flexi-i menu-item-icon menu-item-icon-settings"></div>
          <p class="flexi-i menu-item-name purple">Settings</p>
        </div>

        <div class="flexi-c r bottom-gray">
          <div class="flexi-i menu-item-icon menu-item-icon-info"></div>
          <p class="flexi-i menu-item-name purple">Info</p>
        </div>
        -->
       
        <div class="modal-menu-footer">
         <p class="modal-menu-footer-copyright purple">Pura Aurora version 1.1.1 Beta </p>
        </div>
      </div>
    </div>
  </div>
</template>

<style>
  .modal-body.modal-menu-body {
    width: 320px;
    height: 100vh;
    margin: 0;
    margin-left: auto;
    border-left: 1px solid #370e7a;
  }
  .flexi-i.menu-item-icon {
    flex: 0 0 42px;
    height: 42px;
    margin-right: 5px;
    cursor: pointer;

    background-size: 20px auto;
    background-position: center;
    background-repeat: no-repeat;
  }
  .menu-item-name {
    font: 700 16px/42px 'Open Sans', sans-serif;
    cursor: pointer;
  }

  .menu-item-icon-transactions {
    background-image: url(../assets/images/list.svg);
  }
  .menu-item-icon-mining {
    background-image: url(../assets/images/pick.svg);
  }
  .menu-item-icon-settings {
    background-image: url(../assets/images/settings.svg);
  }
  .menu-item-icon-info {
    background-image: url(../assets/images/icon-info.svg);
    background-size: 12px auto;
  }
  .menu-item-icon-backup {
    background-image: url(../assets/images/backup.svg);
  }
  .menu-item-icon-key {
    background-image: url(../assets/images/key.svg);
  }

  .modal-menu-footer {
    position: absolute;
    bottom: 58px;
    left: 20px;
    width: calc(100% - 40px);
  }
  .modal-menu-footer-copyright {
    font: 400 10px/16px 'Open Sans', sans-serif;
  }
</style>

<script>
  export default {
    data () {
      return {
        isLocked: false
      }
    },
    methods: {
      openModal: function(modalName) {
        this.$root.$emit('launchModal', modalName)
      }
    },
    mounted: function () {
      this.$data.isLocked = RPC.walletIsLocked;
    }
  }
</script>