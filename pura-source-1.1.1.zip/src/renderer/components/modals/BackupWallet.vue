<template>
  <div class="modal-cover">
    <div class="modal-backdrop" @click="$emit('close')"></div>

    <div class="modal-body">
      <div class="modal-header">
        <p class="modal-title">Backup Wallet</p>

        <button class="modal-exit" @click="$emit('close')"></button>
      </div>

      <div class="flexi-c modal-content no-scroll">
        <div class="flexi-i">
          <p class="purple instructions">Press the Save button below to generate a backup of your wallet.</p>
          <div class="alert">
            <p class="success" v-if="success">Backup saved!</p>
            <p class="error" v-if="error">An error occurred. Please try again.</p>
          </div>
        </div>

        <div class="modal-footer">
          <div class="flexi-c r">
            <p class="flexi-i cancel t-center b-purple cursor" @click="$emit('close')">Cancel</p>
            <p class="flexi-i send t-center b-purple cursor" @click="makeBackup()">Save</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
  .modal-body {
    width: calc(100vw - 420px);
    height: calc(100vh - 220px);
    margin: 110px 210px;
  }
  .modal-body p.instructions {
    font: 400 12px/42px 'Open Sans', sans-serif;
    text-align: center;
  }
  .alert {
    text-align: center;
    font: 600 16px 'Open Sans', sans-serif;
    margin-top: 40px;
  }
  .alert .success {
    color: #24b628;
  }
  .alert .error {
    color: #24b628;
  }
</style>

<script>
  export default {
    data () {
      return {
        newPass: '',
        error: false,
        success: false
      }
    },
    methods: {
      makeBackup: function () {
        var vue = this;

        const {dialog} = require('electron').remote;
        dialog.showSaveDialog(
          { defaultPath: RPC.backupdir + 'wallet.dat.' + vue.$moment().format('YYYY-MM-DD-HH-mm') },
          function (fileName) {
            RPC.backupWallet(vue, fileName)
              .then(function(){
                vue.$data.success = true;
                setTimeout(function(){ vue.$emit('close'); }, 2000);
              }, function(){
                vue.$data.error = true;
              });
          }
        );
      }
    }
  }
</script>