<template>
  <div class="modal-cover">
    <div class="modal-backdrop" @click.native="$emit('close')"></div>

    <div class="modal-body">
      <div class="modal-header">
        <p class="modal-subtitle">Current balance</p>
        <p class="modal-title">{{balance}} PURA</p>

        <button class="modal-exit" @click="$emit('close')"></button>
      </div>

      <div class="modal-content no-scroll">
        <div class="flexi-i upper">
          <h1 class="modal-transactions-title t-center purple">Transactions</h1>

          <!--
          <input
            type="text"
            class="input purple transactions-search-input"
            placeholder="Search"
            v-model="search"
          ></input>
          -->
        </div>

        <div class="flexi-i transactions modal-transactions">
          <div class="flexi-i transactions-inner">
            <div class="flexi-c r transaction bottom-gray" v-for="t in transactions" @click="link('/transaction/'+t.id)">
              <div class="flexi-i transaction-date">
                <p class="transaction-month t-center pink">{{t.month}}</p>  
                <p class="transaction-day t-center purple">{{t.day}}</p>  
              </div>
              
              <div class="flexi-i transaction-icon"></div>

              <div class="flexi-i">
                <p class="transaction-kind purple" :class="{'transaction-kind-only': t.label == null}">{{t.kind}} PURA</p>
                <p class="transaction-label pink">{{t.label}}</p>
              </div>

              <div class="flexi-i transaction-value">
                <p class="transaction-value-amount t-right purple">{{t.amount}}</p>
                <p class="transaction-value-currency t-right purple">PURA</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style>
  .upper {
    flex-basis: auto;
  }
  .modal-transactions {
    flex-basis: 580px;
    height: 320px;
    overflow-y: auto;
    padding-bottom: 0;
  }
  .modal-transactions-title {
    padding-bottom: 20px;
    font: 700 32px/36px 'Open Sans', sans-serif;
  }
  .transactions-search-input {
    padding-left: 36px;
    font-weight: 600;

    background-image: url(../../assets/images/search.svg);
    background-size: 20px auto;
    background-position: 10px center;
    background-repeat: no-repeat;
  }
</style>

<script>
  export default {
    data () {
      return {
        balance: '--',
        search: "",
        transactions: [],
        search: ""
      }
    },
    computed: {
      transactions: function() {
        if (this.$data.search == "") { return this.$d.transactions }

        return this.$d.transactions.filter( t => {
          var label = t.label || ""

          return label.toLowerCase().includes(this.$data.search.toLowerCase())
        });
      }
    },
    methods: {
      getBalance: function () { RPC.getBalance(this); },
      getTransactions() { RPC.getTransactions(this); }
    },
    mounted: function() {
      this.getBalance();
      this.getTransactions();
    }
  }
</script>