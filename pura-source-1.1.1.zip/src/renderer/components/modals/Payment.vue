<template>
  <div class="modal-cover">
    <div class="modal-backdrop" @click="$emit('close')"></div>

    <div class="modal-payment-body b-white">
      <div class="modal-content no-scroll">
        <h1 class="modal-payment-title t-center purple">Receive Payment</h1>

        <div class="qr-outer">
          <div class="payment-qr" id="payment-qr"></div>
        </div>

        <div class="fields">
          <label class="label">Address:</label>
          <div class="flexi-c r copy">
            <p class="flexi-i copy-text" id="field-address">{{address}}</p>
            <div class="flexi-i copy-icon" data-clipboard-target="#field-address"></div>
          </div>


          <label class="label">URI:</label>
          <div class="flexi-c r copy copy-last">
            <p class="flexi-i copy-text nowrap" id="field-uri">{{uri}}</p>
            <div class="flexi-i copy-icon" data-clipboard-target="#field-uri"></div>
          </div>

          <div class="flexi-c r">
            <p class="flexi-i cancel t-center b-purple cursor" @click="$emit('close')">Cancel</p>
            <p class="flexi-i send t-center b-purple cursor" @click="generateReceiveQR()">Save</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style>
  .modal-payment-body {
    width: calc(100% - 80px);
    margin: 90px 40px;
    border: 1px solid #370e7a;
    z-index: 900;
  }
  .modal-payment-title {
    font: 700 32px/52px 'Open Sans', sans-serif;
  }
  .qr-outer {
    width: 30%;
    float: left;
  }
  .fields {
    width: 70%;
    float: left;
  }
  .payment-qr {
    width: 210px;
    max-width: calc(100% - 20px);
    height: 210px;
    margin: 20px auto;
    /*background-image: url(../../assets/images/qrcode.svg);
    background-size: 100% auto;
    background-position: center;
    background-repeat: no-repeat;*/
  }
  .copy {
    margin-bottom: 10px;
    border: 1px solid #370e7a;
  }
  .copy-last {
    margin-bottom: 30px;
  }
  .copy-text {
    overflow: hidden;
    padding-left: 10px !important;
    font: 400 14px/45px 'Open Sans', sans-serif;
    color: gray;
  }
  .nowrap {
    white-space: nowrap;
    text-overflow: ellipsis;
    padding-right: 10px;
  }
  .flexi-i.copy-icon {
    flex: 0 0 45px;
    height: 45px;
    background-color: #370e7a;
    background-image: url(../../assets/images/copy.svg);
    background-size: 24px auto;
    background-position: center;
    background-repeat: no-repeat;
    transform: rotate(90deg);
  }
</style>

<script>
  export default {
    data () {
      return {
        address: '--',
        uri: '--',
        message: '',
        amount: '',
        label: ''
      }
    },
    methods: {
      generateQR: function () {
        var vueData = this.$data;

        vueData.uri = 'pura:' + vueData.address +
            '?amount=' + vueData.amount +
            '&label=' + encodeURIComponent(vueData.label.trim()) +
            '&message=' + encodeURIComponent(vueData.message.trim()) +
             "?IS=1";

        console.log(vueData.uri);

        var qrcode = new QRCode(document.getElementById("payment-qr"), {
          text: vueData.uri,
          width: 210,
          height: 210,
          colorDark : "#000000",
          colorLight : "#ffffff",
          correctLevel : QRCode.CorrectLevel.H
        });
      }
    },
    mounted: function () {
      var vueData = this.$data,
          parent = this.$parent;

      new Clipboard('.copy-icon');
      vueData.address = parent.address;
      vueData.label = parent.label;
      vueData.amount = parent.amount;
      vueData.message = parent.message;
      this.generateQR();
    }
  }
</script>