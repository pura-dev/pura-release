<template>
  <div class="modal-cover">
    <div class="modal-backdrop" @click.native="$emit('close')"></div>

    <div class="modal-body">
      <div class="modal-header">
        <p class="modal-title">PURA Mobile Mining</p>

        <button class="modal-exit" @click="$emit('close')"></button>
      </div>

      <div class="flexi-c modal-content">
        <div class="flexi-i">
          <template v-if="$d.mining">
            <p class="mining-rate t-center purple">{{$d.hashRate}} <span class="mining-rate-label purple">h/s</span></p>

            <p class="mining-progress t-center purple"><span class="pink">16</span> accepted | <span class="pink">0</span> rejected</p>

            <div class="flexi-c r mining-dots">
              <div class="flexi-i"><div class="mining-dot" :class="dots[0]"></div></div>
              <div class="flexi-i"><div class="mining-dot" :class="dots[1]"></div></div>
              <div class="flexi-i"><div class="mining-dot" :class="dots[2]"></div></div>
            </div>

            <p class="mining-time t-center purple"><span class="pink mining-time">{{$d.miningTime | hrs}}</span>h <span class="pink mining-time">{{$d.miningTime | min}}</span>m <span class="pink mining-time">{{$d.miningTime | sec}}</span>s</p>
          </template>

          <template v-else>
            <div class="circle-logo"></div>

            <p class="mining-instruction t-center purple">Press the <span class="mining-instruction bold purple">Start button</span></p>
            <p class="mining-instruction t-center purple">below to begin mining.</p>
          </template>
        </div>

        <div class="flexi-i modal-footer modal-mining-footer">
          <label class="label purple">Mining Speed:</label>

          <div class="flexi-c r mining-speed-options">
            <p
              class="flexi-i mining-speed-option t-center purple"
              :class="{'b-purple': $d.hashSpeed=='l'}"
              @click="$s.commit('setMiningSpeed','l')"
            >Low</p>

            <p
              class="flexi-i mining-speed-option t-center purple"
              :class="{'b-purple': $d.hashSpeed=='m'}"
              @click="$s.commit('setMiningSpeed','m')"
            >Med</p>

            <p
              class="flexi-i mining-speed-option t-center purple"
              :class="{'b-purple': $d.hashSpeed=='h'}"
              @click="$s.commit('setMiningSpeed','h')"
            >High</p>
          </div>

          <p class="send t-center b-purple cursor" @click="$s.commit('setMining', !$d.mining)">{{$d.mining ? 'Stop' : 'Start'}}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<style>
  .mining-rate {
    padding-top: 50px !important;
    font: 700 36px/36px 'Open Sans', sans-serif;
  }
  .mining-rate-label {
    font: 600 14px/36px 'Open Sans', sans-serif;
  }
  .mining-progress {
    font: 600 16px/22px 'Open Sans', sans-serif;
  }
  .mining-time {
    font: 600 16px/32px 'Open Sans', sans-serif;
  }
  .mining-dots {
    width: 150px;
    margin: 40px auto;
  }
  .mining-dot {
    width: 14px;
    height: 14px;
    margin: 7px auto;
    border-radius: 4px;
    border: 1px solid #370e7a;
    background: #d6cee3;
    -webkit-transition: all 0.5s; /* Safari */
    transition: all 0.5s;
  }
  .mining-dot-m {
    width: 22px;
    height: 22px;
    margin: 3px auto;
    background: #9b87bc;
    -webkit-transition: all 0.5s; /* Safari */
    transition: all 0.5s;
  }
  .mining-dot-l {
    width: 28px;
    height: 28px;
    margin: 0 auto;
    background: #370e7a;
    -webkit-transition: all 0.5s; /* Safari */
    transition: all 0.5s;
  }
  .circle-logo {
    display: block;
    margin: 50px auto;
    width: 120px;
    height: 120px;
    background-image: url(../../assets/images/logo-circle.svg);
    background-repeat: no-repeat;
    background-size: 120px auto;
    background-position: center;
  }
  .mining-instruction {
    font: 600 20px/32px 'Open Sans', sans-serif;
  }
  .mining-speed-options {
    margin-bottom: 20px;
    border: 1px solid #370e7a;
  }
  .mining-speed-option {
    border-right: 1px solid #370e7a;
    font: 600 16px/42px 'Open Sans', sans-serif;
    cursor: pointer;
  }
  .mining-speed-option:last-child {
    border-right: none;
  }
  .modal-mining-footer {
    flex: 0 0 180px;
  }
</style>

<script>
  export default {
    data () {
      return {
        speed: "h"
      }
    },
    computed: {
      dots: function() {
        var out = [[], [], [], []];
        var step = this.$d.miningTime % 3

        out[step] = ["mining-dot-l"]
        out[step-1] = ["mining-dot-m"]
        out[step+1] = ["mining-dot-m"]

        return out
      }
    }
  }
</script>