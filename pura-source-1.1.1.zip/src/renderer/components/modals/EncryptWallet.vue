<template>
  <div class="modal-cover">
    <div class="modal-backdrop" @click="$emit('close')"></div>

    <div class="modal-body">
      <div class="modal-header">
        <p class="modal-title">Encrypt Wallet</p>

        <button class="modal-exit" @click="$emit('close')"></button>
      </div>

      <div class="flexi-c modal-content no-scroll">
        <div class="flexi-i">
          <label class="label purple">New Passphrase:</label>
          <input
            type="password"
            class="input purple pass-input"
            v-model="newPass"
          ></input>
          <label class="label purple">Confirm Passphrase:</label>
          <input
            type="password"
            class="input purple pass-input"
            v-model="newPassConfirm"
          ></input>
          <p class="error" v-if="hasError">{{error}}</p>
        </div>

        <div class="modal-footer">
          <div class="flexi-c r">
            <p class="flexi-i cancel t-center b-purple cursor" @click="$emit('close')">Cancel</p>
            <p class="flexi-i send t-center b-purple cursor" @click="setPassphrase()">Encrypt</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
  .modal-body {
    width: calc(100vw - 420px);
    height: calc(100vh - 180px);
    margin: 90px 210px;
  }
  .error {
    font: 600 12px/16px 'Open Sans', sans-serif;
    color: red;
    margin-top: 16px;
    text-align: center;
  }
</style>

<script>
  export default {
    data () {
      return {
        newPass: '',
        newPassConfirm: '',
        error: null,
        hasError: false
      }
    },
    methods: {
      setPassphrase: function () {
        var vue = this;

        if (vue.$data.newPass === vue.$data.newPassConfirm) {
          if (vue.$data.newPass.length > 6) {
            const {dialog} = require('electron').remote;
            var dialogOptions = {
              type: 'question',
              title: 'Encrypt Wallet',
              message: 'Warning: If you encrypt your wallet and lose your passphrase, you will LOSE ALL OF YOUR PURA!',
              detail: 'Are you sure you want to encrypt your wallet?',
              buttons: ['Cancel', 'Yes']
            }
            if(dialog.showMessageBox(dialogOptions) === 1) {
              RPC.encryptWallet(vue)
                .then(function(data){
                  setTimeout(() => {
                    var remote = require('electron').remote;
                    remote.getCurrentWindow().reload();
                  }, 1500);
                });
            }
          } else {
            vue.$data.error = "Please enter a passphrase greater than 6 characters in length.";
            vue.$data.hasError = true;
          }
        } else {
          vue.$data.error = "The passphrases you entered do not match. Please try again.";
          vue.$data.hasError = true;
        }
      }
    }
  }
</script>