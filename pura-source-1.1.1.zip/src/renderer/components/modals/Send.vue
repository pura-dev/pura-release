<template>
  <div class="modal-cover">
    <div class="modal-backdrop" @click="$emit('close')"></div>

    <div class="modal-body">
      <div class="modal-header">
        <p class="modal-subtitle">Available to send</p>
        <p class="modal-title">{{balance}} PURA</p>

        <button class="modal-exit" @click="$emit('close')"></button>
      </div>

      <div class="flexi-c modal-content no-scroll">
        <div class="flexi-i">
          <label class="label purple">Pay To:</label>
          <div class="to">
            <input
              type="text"
              class="input purple to-input"
              placeholder="Pura Address"
              @focus="addressActive=true"
              @blur="addressActive=false"
              v-model="address"
            ></input>

            <!--
            <div class="to-suggestions" v-if="addressActive">
              <div class="to-suggestion b-white" v-for="s in toSuggestions" @click="address=s.address; label=s.label">
                <p class="to-suggestion-label purple">{{s.label}}</p>
                <p class="to-suggestion-address purple">{{s.address}}</p>
              </div>
            </div>
            -->
          </div>

          <!--
          <label class="label purple">Label:</label>
          <input type="text" v-model="label" class="input purple input-label" placeholder="Label for Address Book"></input>
          -->

          <label class="label purple">Amount:</label>
          <div class="amount">
            <input
              type="text"
              class="input input-amount purple"
              v-model="amount"
              placeholder="0.00"
            ></input>

            <p class="amount-currency-symbol purple">{{currency}}</p>
            <!--
            <div class="amount-dropdown-button cursor" @click="currencyActive=!currencyActive"></div>

            <div class="amount-currencies b-white" v-if="currencyActive" @blur="currencyActive=false">
              <div class="amount-currency white" @click="currency='$'; currencyActive=false">
                <p class="amount-currency-label t-center purple cursor" :class="{'b-purple': currency=='$'}">USD</p>
              </div>
              <div class="amount-currency white cursor" @click="currency='P'; currencyActive=false">
                <p class="amount-currency-label t-center purple cursor" :class="{'b-purple': currency=='P'}">PURA</p>
              </div>
            </div>
            -->
          </div>

          <div class="flexi-c r checkmark-outer">
            <div class="flexi-i checkmark-container" @click="subtractFee=!subtractFee">
              <div class="checkmark cursor" :class="{'marked': subtractFee}"></div>
              <p class="checkmark-label purple cursor">Subtract Fee From Amount?</p>
            </div>

            <!--
            <div class="flexi-i checkmark-container" @click="privatePay=!privatePay">
              <div class="checkmark cursor" :class="{'marked': privatePay}"></div>
              <p class="checkmark-label purple cursor">PrivatePay</p>
            </div>

            <div class="flexi-i checkmark-container" @click="instaPay=!instaPay">
              <div class="checkmark last cursor" :class="{'marked': instaPay}"></div>
              <p class="checkmark-label purple cursor">InstaPay</p>
            </div>
            -->
          </div>

          <p class="fee gray">Fee: {{fee}} PURA/KB</p>
          <p class="total gray">Total: {{total}} {{currency}}</p>
        </div>

        <div class="modal-footer">
          <div class="flexi-c r">
            <p class="flexi-i cancel t-center b-purple cursor" @click="$emit('close')">Cancel</p>
            <!--<p class="flexi-i send t-center b-purple cursor" @click="$s.commit('sendTransaction', {label, amount}); $emit('close')">Send</p>-->
            <p class="flexi-i send t-center b-purple cursor" @click="commitSend()">Send</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style>
  .to {
    z-index: 950;
  }
  .to-input {
    /*background-image: url(../../assets/images/down.svg);
    background-size: 16px auto;
    background-position: calc(100% - 10px) 16px;
    background-repeat: no-repeat;*/
  }
  .to-suggestions {
    position: absolute;
    top: 45px;
    left: 0;
    width: 100%;
    border: 1px solid #370e7a;
    border-top: none;
    border-bottom: none;
    z-index: 950;
  }
  .to-suggestion {
    padding: 10px;
    border-bottom: 1px solid #370e7a;
  }
  .to-suggestion-label {
    font: 400 12px/12px 'Open Sans', sans-serif;
  }
  .to-suggestion-address {
    font: 600 16px/16px 'Open Sans', sans-serif;
  }
  .amount {
    z-index: 925;
  }
  .input.input-amount {
    padding-left: 18px;
  }
  .amount-currency-symbol {
    position: absolute;
    top: 0;
    left: 8px;
    font: 600 14px/45px 'Open Sans', sans-serif;
  }
  .amount-dropdown-button {
    position: absolute;
    top: 0;
    right: 0;
    width: 40px;
    height: 45px;
    background-image: url(../../assets/images/down.svg);
    background-size: 16px auto;
    background-position: calc(100% - 10px) 16px;
    background-repeat: no-repeat;
  }
  .amount-currencies {
    position: absolute;
    top: 45px;
    right: 0;
    border: 1px solid #370e7a;
    border-top: none;
    z-index: 950;
  }
  .amount-currency {
    display: inline;
    border-bottom: 1px solid #370e7a;
  }
  .amount-currency-label {
    padding: 10px !important;
    font: 600 16px/16px 'Open Sans', sans-serif;
  }
  .fee {
    text-align: right;
    font: 600 10px/16px 'Open Sans', sans-serif;
  }
  .total {
    margin-bottom: 30px !important;
    text-align: right;
    font: 600 28px/36px 'Open Sans', sans-serif;
  }
</style>

<script>
  export default {
    data () {
      return {
        balance: '--',
        subtractFee: false,
        privatePay: false,
        instaPay: false,
        fee: "0.00020000",
        addressActive: false,
        currencyActive: false,
        currency: "P",
        amount: "",
        label: "",
        address: "",
        toSuggestions: []
      }
    },
    methods: {
      getBalance: function () { RPC.getBalance(this); },
      sendPura: function () { RPC.sendPura(this); },
      commitSend: function () {
        var data = '{ "method": "listtransactions" }',
            vueData = this.$data,
            total = parseFloat(vueData.amount);

        if (vueData.subtractFee) total = (vueData.amount - parseFloat(vueData.fee)).toFixed(4);

        const {dialog} = require('electron').remote;
        var dialogOptions = {
          type: 'question',
          title: 'Confirm Send',
          message: 'Please confirm the following transaction:',
          detail: vueData.currency + ' ' + total + ' to ' + vueData.address,
          buttons: ['Cancel', 'Send Now']
        }
        if(dialog.showMessageBox(dialogOptions) === 1) {
          this.sendPura();
          this.$emit('close');
        }
      }
    },
    computed: {
      total: function() {
        var amount = parseFloat(this.$data.amount) || 0

        if (this.$data.subtractFee) {
          return (amount - parseFloat(this.$data.fee)).toFixed(4)
        }
        return amount
      }
    },
    mounted: function() {
      this.getBalance();
    }
  }
</script>