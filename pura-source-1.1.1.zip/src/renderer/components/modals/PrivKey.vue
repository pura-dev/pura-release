<template>
  <div class="modal-cover">
    <div class="modal-backdrop" @click="$emit('close')"></div>

    <div class="modal-body">
      <div class="modal-header">
        <p class="modal-title">Private Key</p>

        <button class="modal-exit" @click="$emit('close')"></button>
      </div>

      <div class="flexi-c modal-content no-scroll">
        <div class="flexi-i">
          <p class="private-key">Your private key:<br /><strong>{{privKey}}</strong></p>
        </div>

        <div class="modal-footer">
          <div class="flexi-c r">
            <p class="flexi-i cancel t-center b-purple cursor" @click="$emit('close')">Close</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
  .modal-body {
    width: calc(100vw - 420px);
    height: calc(100vh - 220px);
    margin: 110px 210px;
  }
  .private-key {
    margin-top: 60px;
    font: 400 12px/14px 'Open Sans', sans-serif;
    text-align: center;
    color: #370f7a;
  }
  .private-key strong {
    font-weight: 600;
    font-size: 14px;
    display: block;
    margin-top: 12px;
  }
</style>

<script>
  export default {
    data () {
      return {
        privKey: ''
      }
    },
    methods: {
      fetch: function () {
        var vue = this,
            vueData = vue.$data,
            parent = vue.$parent;

        RPC.getPrivateKey(vue, parent.address);
      }
    },
    mounted: function () {
      this.fetch();
    }
  }
</script>