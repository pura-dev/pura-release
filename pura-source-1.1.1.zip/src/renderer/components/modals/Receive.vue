<template>
  <div class="modal-cover">
    <div class="modal-backdrop" @click="$emit('close')"></div>

    <div class="modal-body">
      <div class="modal-header">
        <p class="modal-subtitle">Current balance</p>
        <p class="modal-title">{{balance}} PURA</p>

        <button class="modal-exit" @click="$emit('close')"></button>
      </div>

      <div class="flexi-c modal-content no-scroll">
        <div class="flexi-i">
          <label class="label purple">Label:</label>
          <input type="text" class="input purple" v-model="label" placeholder="Label this payment"></input>

          <label class="label purple">Amount:</label>
          <div class="amount">
            <input
              type="text"
              class="input purple input-amount"
              v-model="amount"
              placeholder="0.00"
            ></input>

            <p class="amount-currency-symbol purple">{{currency}}</p>

            <!--
            <div class="amount-dropdown-button cursor" @click="currencyActive=!currencyActive"></div>

            <div class="amount-currencies b-white" v-if="currencyActive" @blur="currencyActive=false">
              <div class="amount-currency white" @click="currency='$'; currencyActive=false">
                <p class="amount-currency-label t-center purple cursor" :class="{'b-purple': currency=='$'}">USD</p>
              </div>
              <div class="amount-currency white" @click="currency='P'; currencyActive=false">
                <p class="amount-currency-label t-center purple cursor" :class="{'b-purple': currency=='P'}">PURA</p>
              </div>
            </div>
            -->
          </div>

          <label class="label purple">Message:</label>
          <input type="text" class="input purple" v-model="message" placeholder="Message for sender"></input>

          <!--
          <div class="flexi-c r checkmark-outer">
            <div class="checkmark-container" @click="instaPay=!instaPay">
              <div class="flexi-i checkmark last cursor" :class="{'marked': instaPay}"></div>
              <p class="flexi-i checkmark-label purple cursor">Request InstaPay</p>
            </div>
          </div>
          -->
        </div>

        <div class="modal-footer">
          <div class="flexi-c r">
            <p class="flexi-i cancel t-center b-purple cursor" @click="$emit('close')">Cancel</p>
            <p class="flexi-i send t-center b-purple cursor" @click="generateRequest()">Request</p>
          </div>
        </div>
      </div>
    </div>

    <payment v-if="paymentModal" @close="paymentModal=false"></payment>
  </div>
</template>

<style>
  .amount {
    z-index: 925;
  }
  .input.input-amount {
    padding-left: 18px;
  }
  .amount-currencies {
    position: absolute;
    top: 45px;
    right: 0;
    border: 1px solid #370e7a;
    border-top: none;
    border-bottom: none;
    z-index: 950;
  }
  .amount-currency {
    display: inline;
    border-bottom: 1px solid #370e7a;
  }
  .amount-currency-label {
    padding: 10px !important;
    font: 600 16px/16px 'Open Sans', sans-serif;
  }
  .amount-currency-symbol {
    position: absolute;
    top: 0;
    left: 8px;
    font: 600 14px/45px 'Open Sans', sans-serif;
  }
  .amount-dropdown-button {
    position: absolute;
    top: 0;
    right: 0;
    width: 40px;
    height: 45px;
    background-image: url(../../assets/images/down.svg);
    background-size: 16px auto;
    background-position: calc(100% - 10px) 16px;
    background-repeat: no-repeat;
  }
  .margin-top {
    margin-top: 180px;
  }
</style>

<script>
  import payment from './Payment.vue'

  export default {
    components: { 
      payment
    },
    data () {
      return {
        balance: '--',
        paymentModal: false,
        instaPay: false,
        currencyActive: false,
        currency: "P",
        amount: "",
        address: "",
        label: "",
        message: ""
      }
    },
    methods: {
      generateRequest: function () {
        var data = '{ "method": "getaccountaddress", "params": [""] }',
            vueData = this.$data;

        RPC.call(data).then(function(data) {
          var address = data.result;
          vueData.address = address;
          vueData.paymentModal=true;
          });
      },
      getBalance: function () { RPC.getBalance(this); },
    computed: {
      total: function() {
        var amount = parseFloat(this.$data.amount) || 0

        if (this.$data.subtractFee) {
          return (amount - parseFloat(this.$data.fee)).toFixed(4)
        }
        return amount.toFixed(2)
      }
    },
    mounted: function() {
      this.getBalance();
    }
  }
</script>