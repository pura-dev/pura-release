import Vue from 'vue'
import Vuex from 'vuex'

import modules from './modules'

Vue.use(Vuex)

export default new Vuex.Store({
  modules,
  strict: process.env.NODE_ENV !== 'production',
  state: {
    mining: true,
    miningTime: 1934,
    hashRate: 17.62,
    hashSpeed: "h",
    balance: 14278.34,
    transactions: []
  },
  mutations: {
    setMining (state, val) {
      state.mining = val;
    },
    setMiningSpeed (state, val) {
      state.hashSpeed = val;

      if (val == "h") {
        state.hashRate = 17.62;
      } else if (val == "m") {
        state.hashRate = 11.94;
      } else {
        state.hashRate = 5.78;
      }
    },
    iterateMiningTimer (state) {
      state.miningTime++;
    },
    sendTransaction (state, {label, amount}) {
      console.log(label)
      console.log(amount)
      state.balance -= amount;
      state.transactions.unshift({
        id: "",
        month: "DEC",
        day: "03",
        kind: "Sent",
        label: label,
        amount: ("-" + amount.toString())
      })
    }
  }
})