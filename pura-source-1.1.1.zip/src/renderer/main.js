import Vue from 'vue'
import axios from 'axios'

import App from './App'
import router from './router'
import store from './store'
import mixins from './mixins'

import 'jquery/dist/jquery.min.js'

// Plugins
import moment from 'moment'
import VueMomentJS from 'vue-momentjs'
import VTooltip from 'v-tooltip'
 
Vue.use(VueMomentJS, moment)
Vue.use(VTooltip)

// register global mixins.
Vue.mixin(mixins)

// register store with a shorter name
Vue.prototype.$s = store
Vue.prototype.$d = store.state

if (!process.env.IS_WEB) Vue.use(require('vue-electron'))
Vue.http = Vue.prototype.$http = axios
Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  components: { App },
  router,
  store,
  template: '<App/>'
}).$mount('#app')
